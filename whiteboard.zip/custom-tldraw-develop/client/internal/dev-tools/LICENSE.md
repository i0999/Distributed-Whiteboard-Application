See [tldraw license](https://github.com/tldraw/tldraw/blob/main/LICENSE.md).
