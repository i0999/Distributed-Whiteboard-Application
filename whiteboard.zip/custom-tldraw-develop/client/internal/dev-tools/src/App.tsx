import Bisect from './Bisect/Bisect'

function App() {
	return <Bisect />
}

export default App
