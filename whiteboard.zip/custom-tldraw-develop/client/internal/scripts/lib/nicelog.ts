export function nicelog(...args: any[]) {
	console.log(...args)
}
