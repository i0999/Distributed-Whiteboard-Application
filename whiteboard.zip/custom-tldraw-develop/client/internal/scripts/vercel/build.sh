#!/usr/bin/env bash
set -eux

yarn run -T lazy build --filter=apps/examples --filter=packages/tldraw