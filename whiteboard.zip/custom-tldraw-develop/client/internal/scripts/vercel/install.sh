#!/usr/bin/env bash
set -eux

yarn